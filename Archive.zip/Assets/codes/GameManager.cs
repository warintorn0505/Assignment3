using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Text scoreText;
    public Text gameOverText;

    int playerScore = 0;

    void Start()
    {
        // Set initial score text
        scoreText.text = "Score: 0";

        // Hide Game Over at start
        gameOverText.enabled = false;

        // Make sure game is running
        Time.timeScale = 1f;
    }

    public void AddScore()
    {
        playerScore++;

        // Update score with label
        scoreText.text = "Score: " + playerScore;
    }

    public void PlayerDied()
    {
        // Show Game Over text
        gameOverText.enabled = true;

        // Freeze the game
        Time.timeScale = 0f;
    }
}