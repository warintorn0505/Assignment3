using UnityEngine;

public class ShipControl : MonoBehaviour
{
    public GameManager gameManager;
    public GameObject bulletPrefab;
    public float speed = 10f;
    public float xLimit = 7f;

    public float normalReloadTime = 0.5f;
    public float rapidFireReloadTime = 0.15f;

    public float rapidFireDuration = 5f;
    public float spreadShotDuration = 5f;

    float elapsedTime = 0f;

    bool rapidFireActive = false;
    bool spreadShotActive = false;

    float rapidFireTimer = 0f;
    float spreadShotTimer = 0f;

    void Update()
    {
        elapsedTime += Time.deltaTime;

        if (rapidFireActive)
        {
            rapidFireTimer -= Time.deltaTime;
            if (rapidFireTimer <= 0f)
            {
                rapidFireActive = false;
            }
        }

        if (spreadShotActive)
        {
            spreadShotTimer -= Time.deltaTime;
            if (spreadShotTimer <= 0f)
            {
                spreadShotActive = false;
            }
        }

        float xInput = Input.GetAxis("Horizontal");
        transform.Translate(xInput * speed * Time.deltaTime, 0f, 0f);

        Vector3 position = transform.position;
        position.x = Mathf.Clamp(position.x, -xLimit, xLimit);
        transform.position = position;

        float currentReloadTime = rapidFireActive ? rapidFireReloadTime : normalReloadTime;

        if (Input.GetButtonDown("Jump") && elapsedTime > currentReloadTime)
        {
            Shoot();
            elapsedTime = 0f;
        }
    }

    void Shoot()
    {
        Vector3 spawnPos = transform.position + new Vector3(0, 1.2f, 0);

        if (spreadShotActive)
        {
            SpawnBullet(spawnPos, Vector2.up);
            SpawnBullet(spawnPos + new Vector3(-0.3f, 0f, 0f), new Vector2(-0.25f, 1f));
            SpawnBullet(spawnPos + new Vector3(0.3f, 0f, 0f), new Vector2(0.25f, 1f));
        }
        else
        {
            SpawnBullet(spawnPos, Vector2.up);
        }
    }

    void SpawnBullet(Vector3 spawnPos, Vector2 direction)
    {
        GameObject bullet = Instantiate(bulletPrefab, spawnPos, Quaternion.identity);

        Bullet bulletScript = bullet.GetComponent<Bullet>();
        if (bulletScript != null)
        {
            bulletScript.SetDirection(direction);
        }
    }

    public void ActivateRapidFire()
    {
        rapidFireActive = true;
        rapidFireTimer = rapidFireDuration;
    }

    public void ActivateSpreadShot()
    {
        spreadShotActive = true;
        spreadShotTimer = spreadShotDuration;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Meteor") || other.CompareTag("Enemy"))
        {
            gameManager.PlayerDied();
        }
    }
}