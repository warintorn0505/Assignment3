using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 10f;
    GameManager gameManager;

    private Vector2 moveDirection = Vector2.up;

    void Start()
    {
        gameManager = GameObject.FindFirstObjectByType<GameManager>();

        Rigidbody2D rigidBody = GetComponent<Rigidbody2D>();
        rigidBody.linearVelocity = moveDirection * speed;
    }

    public void SetDirection(Vector2 direction)
    {
        moveDirection = direction.normalized;
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Meteor"))
        {
            Destroy(other.gameObject);
            gameManager.AddScore();
            Destroy(gameObject);
        }
        else if (other.gameObject.CompareTag("Enemy"))
        {
            Destroy(other.gameObject);
            gameManager.AddScore();
            gameManager.AddScore(); // enemy gives 2 points
            Destroy(gameObject);
        }
    }
}