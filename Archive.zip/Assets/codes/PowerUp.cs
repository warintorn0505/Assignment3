using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerUpType
    {
        RapidFire,
        SpreadShot
    }

    public PowerUpType powerUpType;
    public float fallSpeed = 2f;

    void Update()
    {
        transform.Translate(0f, -fallSpeed * Time.deltaTime, 0f);

        if (transform.position.y < -7f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        ShipControl ship = other.GetComponent<ShipControl>();

        if (ship != null)
        {
            if (powerUpType == PowerUpType.RapidFire)
            {
                ship.ActivateRapidFire();
            }
            else if (powerUpType == PowerUpType.SpreadShot)
            {
                ship.ActivateSpreadShot();
            }

            Destroy(gameObject);
        }
    }
}